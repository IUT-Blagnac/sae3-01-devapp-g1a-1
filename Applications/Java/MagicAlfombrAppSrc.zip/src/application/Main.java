package application;
	
import java.util.Optional;
import java.util.Timer;

import application.model.Config;
import application.model.ConfigFileAccess;
import application.model.DataReader;
import application.view.ConfigController;
import application.view.MainMenuController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;


public class Main extends Application {
	
	public Stage menuStage;
	public Config config;
	public DataReader dataReader;
	public ConfigFileAccess configAccess;
	public MainMenuController menuCtrl;
	public Updater up;
	public Timer t;
	
	@Override
	public void start(Stage primaryStage) {
		this.menuStage = primaryStage;
		this.configAccess = new ConfigFileAccess();
		this.config = configAccess.readFile();
		this.dataReader = new DataReader();
		this.t = new Timer();
		showMenu();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	/**
	 * Affiche le menu (l'acceuil) de l'application
	 */
	public void showMenu() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/MainMenuView.fxml"));
			BorderPane menu = loader.load();
			menuCtrl = loader.getController();
			menuCtrl.setMain(this);
			
			Scene menuScene = new Scene(menu, 1080, 720);
			
			this.menuStage.setTitle("MagicAlfombrApp");
			this.menuStage.setScene(menuScene);
			this.menuStage.getIcons().add(new Image(Main.class.getResource("ressource/icon.png").toString()));
			this.menuStage.setOnCloseRequest(event -> quit(event));
			
			this.menuStage.show();
			
			this.up = new Updater(menuCtrl);
			this.t.schedule(up, this.config.frec*1000, this.config.frec*1000);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Affiche la page de configuration de l'application
	 */
	public void showConfig() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/ConfigView.fxml"));
			BorderPane config = loader.load();
			ConfigController ctrl = loader.getController();
			ctrl.setMain(this);
			
			Stage configStage = new Stage();
			Scene configScene = new Scene(config, 800, 600);
			
			configStage.setTitle("Configuration");
			configStage.setScene(configScene);
			configStage.getIcons().add(new Image(Main.class.getResource("ressource/icon.png").toString()));
			configStage.initOwner(menuStage);
			configStage.initModality(Modality.WINDOW_MODAL);

			ctrl.setStage(configStage);
			
			configStage.showAndWait();
			
			menuCtrl.checkState();
			menuCtrl.updateAllData();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Affiche un message de confirmation avant de quitter l'application
	 */
	public void quit(WindowEvent event) {
		if (event != null) event.consume();
		Stage stage = (Stage) event.getSource();
		
		Alert dialog = new Alert(AlertType.CONFIRMATION);
		dialog.setTitle("Fermeture de l'App");
		dialog.setContentText("Voulez-vous réellement quitter ?");
		dialog.setHeaderText("Quitter ?");
		dialog.initOwner(stage);
		
		Optional<ButtonType> rep = dialog.showAndWait();
		
		if (rep.orElse(null) == ButtonType.OK) {
			this.menuStage.close();
		}
	}
}
