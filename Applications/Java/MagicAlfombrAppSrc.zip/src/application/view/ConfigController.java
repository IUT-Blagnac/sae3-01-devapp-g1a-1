package application.view;

import java.io.File;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import application.Main;
import application.model.Config;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class ConfigController implements Initializable {

	//Début des attributs FXML
	public TextField serverField;
	public TextField outField;
	public Slider timeSlider;
	public Slider frecSlider;
	
	public CheckBox activityShow;
	public TextField activityMin;
	public TextField activityMax;
	
	public CheckBox humidityShow;
	public TextField humidityMin;
	public TextField humidityMax;
	
	public CheckBox coShow;
	public TextField coMin;
	public TextField coMax;
	
	public CheckBox illuminShow;
	public TextField illuminMin;
	public TextField illuminMax;
	
	public CheckBox infraShow;
	public TextField infraMin;
	public TextField infraMax;
	
	public CheckBox pressureShow;
	public TextField pressureMin;
	public TextField pressureMax;
	
	public CheckBox tempShow;
	public TextField tempMin;
	public TextField tempMax;
	
	public CheckBox tvocShow;
	public TextField tvocMin;
	public TextField tvocMax;
	
	public Button valid;
	public Button cancel;
	public Button ModifOut;
	//Fin des attributs FXML
	
	public boolean error;
	
	public Stage stage;
	public Main main;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
	}
	
	/**
	 * Affecte le paramètre _stage à l'attribut stage du controleur
	 * @param _stage
	 */
	public void setStage(Stage _stage) {
		this.stage = _stage;
		this.stage.setOnCloseRequest(event -> quit(event));
	}
	
	/**
	 * Affecte le paramètre _main à l'attribut main du controleur
	 * @param _main
	 */
	public void setMain(Main _main) {
		this.main = _main;
		readValues();
	}
	
	/**
	 * Ferme la page de configuration sans valider les modifications
	 * (Bouton Annuler)
	 */
	@FXML
	public void cancel() {
		if (stage!=null) stage.close();
	}
	
	/**
	 * Affiche un pop-up de confirmation avant de quitter la page de configuration (sans enregistrer)
	 * (s'exécute OnCloseRequest du stage)
	 */
	public void quit(WindowEvent event) {
		
		if (event != null) event.consume();

		Alert dialog = new Alert(AlertType.CONFIRMATION);
		dialog.setTitle("Fermeture de l'App");
		dialog.setContentText("Voulez-vous réellement quitter ?");
		dialog.setHeaderText("Quitter ?");
		dialog.initOwner(stage);
		
		Optional<ButtonType> rep = dialog.showAndWait();
		
		if (rep.orElse(null) == ButtonType.OK) {
			this.stage.close();
		}
	}
	
	/**
	 * Affiche un pop-up de confirmation avant de fermer la page de configuration EN ENREGISTRANT les modifications
	 * (Bouton Valider)
	 */
	@FXML
	public void valid() {
		this.error = false;
		
		checkMinMax(this.activityMax);
		checkMinMax(this.activityMin);
		
		checkMinMax(this.coMax);
		checkMinMax(this.coMin);
		
		checkMinMax(this.humidityMax);
		checkMinMax(this.humidityMin);
		
		checkMinMax(this.illuminMax);
		checkMinMax(this.illuminMin);
		
		checkMinMax(this.infraMax);
		checkMinMax(this.infraMin);
		
		checkMinMax(this.pressureMax);
		checkMinMax(this.pressureMin);
		
		checkMinMax(this.tempMax);
		checkMinMax(this.tempMin);
		
		checkMinMax(this.tvocMax);
		checkMinMax(this.tvocMin);
		
		if (this.error) {
			Alert errorDialog = new Alert(AlertType.ERROR);
			errorDialog.setTitle("Erreur");
			errorDialog.setContentText("Des champs ne sont pas valides");
			errorDialog.setHeaderText("Veuillez modifier");
			errorDialog.initOwner(stage);
			
			errorDialog.showAndWait();
			
			return;
		}
		
		Alert dialog = new Alert(AlertType.CONFIRMATION);
		dialog.setTitle("Confirmer les changements");
		dialog.setContentText("Conserver les changements effectués ?");
		dialog.setHeaderText("Valider ?");
		dialog.initOwner(stage);
		
		Optional<ButtonType> rep = dialog.showAndWait();
		
		if (rep.orElse(null) == ButtonType.OK) {
			setValues();
			this.main.configAccess.writeToFile(this.main.config);
			this.stage.close();
		}
	}
	
	/**
	 * Permet de choisir le dossier d'enregistrement des données mettre son chemin absolu dans le champs "outField"
	 */
	@FXML
	public void modifOutField() {
		DirectoryChooser dir = new DirectoryChooser();
		
		File initialFile = new File(this.outField.getText());
		if (initialFile.exists() && initialFile.isDirectory()) dir.setInitialDirectory(initialFile);

		File file = dir.showDialog(stage);
		try {
			this.outField.setText(file.getAbsolutePath());
		} catch (NullPointerException e) {}
		
	}
	
	/**
	 * S'exécute à chaque modification d'une des boite de sélection
	 * Vérifie que les champs correspondant à une boite "Montrer" désactivée sont désactivés et vice-versa
	 */
	@FXML
	public void checkState() {
		this.activityMax.setDisable(!this.activityShow.isSelected());
		this.activityMin.setDisable(!this.activityShow.isSelected());
		
		this.coMax.setDisable(!this.coShow.isSelected());
		this.coMin.setDisable(!this.coShow.isSelected());
		
		this.humidityMax.setDisable(!this.humidityShow.isSelected());
		this.humidityMin.setDisable(!this.humidityShow.isSelected());
		
		this.illuminMax.setDisable(!this.illuminShow.isSelected());
		this.illuminMin.setDisable(!this.illuminShow.isSelected());
		
		this.infraMax.setDisable(!this.infraShow.isSelected());
		this.infraMin.setDisable(!this.infraShow.isSelected());
		
		this.pressureMax.setDisable(!this.pressureShow.isSelected());
		this.pressureMin.setDisable(!this.pressureShow.isSelected());
		
		this.tempMax.setDisable(!this.tempShow.isSelected());
		this.tempMin.setDisable(!this.tempShow.isSelected());
		
		this.tvocMax.setDisable(!this.tvocShow.isSelected());
		this.tvocMin.setDisable(!this.tvocShow.isSelected());
	}
	
	/**
	 * Permet de verifier qu'un champs texte (textField) contient bien un "int"
	 * @param textField
	 */
	public void checkMinMax(TextField textField) {
		
		try {
			Integer.parseInt(textField.getText());
			textField.getStyleClass().remove("wrong");
		} catch (Exception e) {
			this.error = true;
			if (!textField.getStyleClass().contains("wrong")) {
				textField.getStyleClass().add("wrong");
			}
		}
		
	}
	
	/**
	 * S'exécute à l'ouverture de la page de configuration
	 * Lit les données de configuration atuelles et les rentre dans le champs correspondant
	 */
	public void readValues() {
		Config config = this.main.config;
		
		this.serverField.setText(config.server);
		this.outField.setText(config.outFolder);
		this.timeSlider.setValue(config.timeSleep / 3600);
		this.frecSlider.setValue(config.frec / 60);
		
		this.activityShow.setSelected(config.toRead.get(0));
		this.activityMax.setText(config.max.get(0).toString());
		this.activityMin.setText(config.min.get(0).toString());
		
		this.coShow.setSelected(config.toRead.get(1));
		this.coMax.setText(config.max.get(1).toString());
		this.coMin.setText(config.min.get(1).toString());
		
		this.humidityShow.setSelected(config.toRead.get(2));
		this.humidityMax.setText(config.max.get(2).toString());
		this.humidityMin.setText(config.min.get(2).toString());
		
		this.illuminShow.setSelected(config.toRead.get(3));
		this.illuminMax.setText(config.max.get(3).toString());
		this.illuminMin.setText(config.min.get(3).toString());
		
		this.infraShow.setSelected(config.toRead.get(4));
		this.infraMax.setText(config.max.get(4).toString());
		this.infraMin.setText(config.min.get(4).toString());
		
		this.pressureShow.setSelected(config.toRead.get(5));
		this.pressureMax.setText(config.max.get(5).toString());
		this.pressureMin.setText(config.min.get(5).toString());
		
		this.tempShow.setSelected(config.toRead.get(6));
		this.tempMax.setText(config.max.get(6).toString());
		this.tempMin.setText(config.min.get(6).toString());
		
		this.tvocShow.setSelected(config.toRead.get(7));
		this.tvocMax.setText(config.max.get(7).toString());
		this.tvocMin.setText(config.min.get(7).toString());
		
		checkState();
		this.cancel.requestFocus();
	}
	
	/**
	 * Enregistre les données des champs modifié ou pas dans l'Objet de type Config qui "contient" les données de configuration
	 */
	public void setValues() {
		Config config = this.main.config;
		
		config.server = this.serverField.getText();
		config.outFolder = this.outField.getText();
		config.timeSleep = (int) (this.timeSlider.getValue() * 3600);
		config.frec = (int) (this.frecSlider.getValue() * 60);
		
		config.toRead.set(0, this.activityShow.isSelected());
		config.max.set(0, Integer.parseInt(this.activityMax.getText()));
		config.min.set(0, Integer.parseInt(this.activityMin.getText()));
		
		config.toRead.set(1, this.coShow.isSelected());
		config.max.set(1, Integer.parseInt(this.coMax.getText()));
		config.min.set(1, Integer.parseInt(this.coMin.getText()));
		
		config.toRead.set(2, this.humidityShow.isSelected());
		config.max.set(2, Integer.parseInt(this.humidityMax.getText()));
		config.min.set(2, Integer.parseInt(this.humidityMin.getText()));
		
		config.toRead.set(3, this.illuminShow.isSelected());
		config.max.set(3, Integer.parseInt(this.illuminMax.getText()));
		config.min.set(3, Integer.parseInt(this.illuminMin.getText()));
		
		config.toRead.set(4, this.infraShow.isSelected());
		config.max.set(4, Integer.parseInt(this.infraMax.getText()));
		config.min.set(4, Integer.parseInt(this.infraMin.getText()));
		
		config.toRead.set(5, this.pressureShow.isSelected());
		config.max.set(5, Integer.parseInt(this.pressureMax.getText()));
		config.min.set(5, Integer.parseInt(this.pressureMin.getText()));
		
		config.toRead.set(6, this.tempShow.isSelected());
		config.max.set(6, Integer.parseInt(this.tempMax.getText()));
		config.min.set(6, Integer.parseInt(this.tempMin.getText()));
		
		config.toRead.set(7, this.tvocShow.isSelected());
		config.max.set(7, Integer.parseInt(this.tvocMax.getText()));
		config.min.set(7, Integer.parseInt(this.tvocMin.getText()));
		
	}

}
