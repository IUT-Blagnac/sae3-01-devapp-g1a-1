package application.view;

import java.net.URL;
import java.util.ResourceBundle;

import application.Main;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;

public class MainMenuController implements Initializable {

	public Main main;
	
	@FXML
	public BarChart<String, Integer> activity;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
	}
	
	public void setMain(Main _main) {
		this.main = _main;
		updateData();
	}
	
	public void updateData() {
		XYChart.Series<String, Integer> series = new XYChart.Series<String, Integer>();
		series.getData().add(new XYChart.Data<String, Integer>("min", this.main.config.min.get(0)));
		series.getData().add(new XYChart.Data<String, Integer>("actual", 1500));
		series.getData().add(new XYChart.Data<String, Integer>("max", this.main.config.max.get(0)));

		this.activity.getData().add(series);
	}
	
	@FXML
	public void openConfig() {
		this.main.showConfig();
	}

}
