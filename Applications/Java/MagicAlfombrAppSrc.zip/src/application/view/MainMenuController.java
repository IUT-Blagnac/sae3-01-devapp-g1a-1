package application.view;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import application.Main;
import application.model.DataArray;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

public class MainMenuController implements Initializable {

	public Main main;
	
	@FXML
	public LineChart<String, Integer> activityChart;
	public LineChart<String, Integer> coChart;
	public LineChart<String, Integer> humidityChart;
	public LineChart<String, Integer> illuminChart;
	public LineChart<String, Integer> infraChart;
	public LineChart<String, Integer> pressureChart;
	public LineChart<String, Integer> temperatureChart;
	public LineChart<String, Integer> tvocChart;
	
	@FXML
	public NumberAxis activityAxis;
	public NumberAxis coAxis;
	public NumberAxis humidityAxis;
	public NumberAxis illuminAxis;
	public NumberAxis infraAxis;
	public NumberAxis pressureAxis;
	public NumberAxis temperatureAxis;
	public NumberAxis tvocAxis;
	
	@FXML
	public Pane activityOff;
	public Pane coOff;
	public Pane humidityOff;
	public Pane illuminOff;
	public Pane infraOff;
	public Pane pressureOff;
	public Pane temperatureOff;
	public Pane tvocOff;
	
	@FXML
	public Label activityOffLabel;
	public Label coOffLabel;
	public Label humidityOffLabel;
	public Label illuminOffLabel;
	public Label infraOffLabel;
	public Label pressureOffLabel;
	public Label temperatureOffLabel;
	public Label tvocOffLabel;
	
	public List<DataArray> data;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		this.data = new ArrayList<DataArray>();
		for (int i = 0; i < 8; i++) {
			this.data.add(new DataArray());
		}
	}
	
	/**
	 * Affecte le paramètre _main à l'attribut main du controleur
	 * @param _main
	 */
	public void setMain(Main _main) {
		this.main = _main;
		checkState();
	}
	
	/**
	 * Appelle la méthode updateData() pour chaque graphe après avoir appelé checkState()
	 */
	public void updateAllData() {
		checkState();
		updateData(activityChart, 0, "activity.dce", "Activité");
		updateData(coChart, 1, "co2.dce", "Co2");
		updateData(humidityChart, 2, "humidity.dce", "Humidité");
		updateData(illuminChart, 3, "illumination.dce", "Luminosité");
		updateData(infraChart, 4, "infrared.dce", "Infra-rouge");
		updateData(pressureChart, 5, "pressure.dce", "Pression");
		updateData(temperatureChart, 6, "temperature.dce", "Température");
		updateData(tvocChart, 7, "tvoc.dce", "Composés organiques");
	}
	
	/**
	 * Met à jour les données dans le graphe lc, en prenant les données dans le fichier file
	 * @param lc
	 * @param index (index correspondant à la case du tableau correspondant au type du graphe)
	 * @param file
	 * @param name
	 */
	public void updateData(LineChart<String, Integer> lc, int index, String file, String name) {
		this.data.get(index).add(this.main.dataReader.getData(this.main.config.outFolder + "/" + file));
		
		Series<String, Integer> serie = new Series<String, Integer>();
		serie.setName(name);
		for (int i = 0; i < this.data.get(index).getLast(); i++) {
			serie.getData().add(new Data<String, Integer>(""+i, this.data.get(index).get(i)));
		}
		
		lc.getData().add(serie);
	}
	
	/**
	 * Met à jour le min et le max pour un graphe donné
	 * @param lc
	 * @param index (index correspondant à la case du tableau correspondant au type du graphe)
	 * @param na axes du graphe
	 */
	public void setMinMax(LineChart<String, Integer> lc, int index, NumberAxis na) {
		lc.getData().clear();
		
		int gap = (int) ((this.main.config.max.get(index) - this.main.config.min.get(index)) * 0.1);
		gap = Math.max(gap, 1);
		na.setAutoRanging(false);
		na.setLowerBound((int) this.main.config.min.get(index)- 2*gap);
		na.setUpperBound((int) this.main.config.max.get(index)+ 2*gap);
		na.setTickUnit(gap);
		
		Series<String, Integer> max = new Series<String, Integer>();
		max.setName("Max");
		Platform.runLater(() -> 
        	max.getNode().lookup(".chart-series-line").setStyle("-fx-stroke: #cc0000;")
		);
		for (int i = 0; i < 10; i++) {
			max.getData().add(new Data<String, Integer>(""+i, this.main.config.max.get(index)));
		}
		
		Series<String, Integer> min = new Series<String, Integer>();
		min.setName("Min");
		Platform.runLater(() -> 
    		min.getNode().lookup(".chart-series-line").setStyle("-fx-stroke: #0000cc;")
		);
		for (int i = 0; i < 10; i++) {
			min.getData().add(new Data<String, Integer>(""+i, this.main.config.min.get(index)));
		}
		
		List<Series<String, Integer>> series = new ArrayList<Series<String, Integer>>();
		series.add(min);
		series.add(max);
		lc.getData().addAll(series);
	}
	
	/**
	 * verifie que les graphes sont dans un état correspondant à celui décrit par le fichier de configuration
	 */
	public void checkState() {
		
		this.activityOff.setVisible(!this.main.config.toRead.get(0));
		this.coOff.setVisible(!this.main.config.toRead.get(1));
		this.humidityOff.setVisible(!this.main.config.toRead.get(2));
		this.illuminOff.setVisible(!this.main.config.toRead.get(3));
		this.infraOff.setVisible(!this.main.config.toRead.get(4));
		this.pressureOff.setVisible(!this.main.config.toRead.get(5));
		this.temperatureOff.setVisible(!this.main.config.toRead.get(6));
		this.tvocOff.setVisible(!this.main.config.toRead.get(7));
		
		if (this.main.config.toRead.get(0)) this.activityOffLabel.setOpacity(0);
		else this.activityOffLabel.setOpacity(1);
		if (this.main.config.toRead.get(1)) this.coOffLabel.setOpacity(0);
		else this.coOffLabel.setOpacity(1);
		if (this.main.config.toRead.get(2)) this.humidityOffLabel.setOpacity(0);
		else this.humidityOffLabel.setOpacity(1);
		if (this.main.config.toRead.get(3)) this.illuminOffLabel.setOpacity(0);
		else this.illuminOffLabel.setOpacity(1);
		if (this.main.config.toRead.get(4)) this.infraOffLabel.setOpacity(0);
		else this.infraOffLabel.setOpacity(1);
		if (this.main.config.toRead.get(5)) this.pressureOffLabel.setOpacity(0);
		else this.pressureOffLabel.setOpacity(1);
		if (this.main.config.toRead.get(6)) this.temperatureOffLabel.setOpacity(0);
		else this.temperatureOffLabel.setOpacity(1);
		if (this.main.config.toRead.get(7)) this.tvocOffLabel.setOpacity(0);
		else this.tvocOffLabel.setOpacity(1);
		
		if (this.main.config.toRead.get(0)) setMinMax(activityChart, 0, activityAxis);
		else activityChart.getData().clear();
		if (this.main.config.toRead.get(1)) setMinMax(coChart, 1, coAxis);
		else coChart.getData().clear();
		if (this.main.config.toRead.get(2)) setMinMax(humidityChart, 2, humidityAxis);
		else humidityChart.getData().clear();
		if (this.main.config.toRead.get(3)) setMinMax(illuminChart, 3, illuminAxis);
		else illuminChart.getData().clear();
		if (this.main.config.toRead.get(4)) setMinMax(infraChart, 4, infraAxis);
		else infraChart.getData().clear();
		if (this.main.config.toRead.get(5)) setMinMax(pressureChart, 5, pressureAxis);
		else pressureChart.getData().clear();
		if (this.main.config.toRead.get(6)) setMinMax(temperatureChart, 6, temperatureAxis);
		else temperatureChart.getData().clear();
		if (this.main.config.toRead.get(7)) setMinMax(tvocChart, 7, tvocAxis);
		else tvocChart.getData().clear();
	}
	
	
	@FXML
	public void openConfig() {
		this.main.showConfig();
	}

}
