package application;

import java.util.TimerTask;

import application.view.MainMenuController;
import javafx.application.Platform;

public class Updater extends TimerTask {

	MainMenuController ctrl;
	
	public Updater(MainMenuController _ctrl) {
		this.ctrl = _ctrl;
	}
	
	@Override
	public void run() {
		Platform.runLater(() -> 
			this.ctrl.updateAllData()
		);
		
	}

}
