package application.model;

import java.io.BufferedReader;
import java.io.FileReader;

public class DataReader {
	
	/**
	 * lit le fichier filename pour récupérer la valeur
	 * @param fileName
	 * @return la valeur lue sous forme d'entier ou 0 si la valeur était invalide ou inexistante
	 */
	public int getData(String fileName) {
		try {
			
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			String res = reader.readLine();
			reader.close();
			return Integer.parseInt(res);
			
		} catch (Exception e) {
			return 0;
		}
	}
	
}
