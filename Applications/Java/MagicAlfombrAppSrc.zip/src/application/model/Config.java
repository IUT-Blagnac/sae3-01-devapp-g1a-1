package application.model;

import java.util.ArrayList;
import java.util.List;

public class Config {
	
	public String server;
	public String outFolder;
	
	public List<Boolean> toRead;
	public List<Integer> max;
	public List<Integer> min;
	
	public int timeSleep;
	public int frec;
	
	/**
	 * Constructeur par défaut
	 */
	public Config() {
		this.server = "none";
		this.outFolder = "none";
		this.timeSleep = 0;
		this.frec = 0;
		
		this.toRead = new ArrayList<Boolean>();
		this.max = new ArrayList<Integer>();
		this.min = new ArrayList<Integer>();
		
		for (int i = 0; i < 8; i++) {
			this.toRead.add(false);
			this.max.add(0);
			this.min.add(0);
		}
	}
	
	/**
	 * Constructeur paramètré
	 */
	public Config(String _server, String _outFolder, List<Boolean> _toRead, List<Integer> _max, List<Integer> _min, int _timeSleep, int _frec) {
		this.server = _server;
		this.outFolder = _outFolder;
		this.toRead = _toRead;
		this.max = _max;
		this.min = _min;
		this.timeSleep = _timeSleep;
		this.frec = _frec;
	}

	/**
	 * Méthode toString générée automatiquement
	 */
	@Override
	public String toString() {
		return "Config [server=" + server + ", outFolder=" + outFolder
				+ ", toRead=" + toRead + ", max=" + max + ", min=" + min + ", timeSleep=" + timeSleep + ", frec=" + frec
				+ "]";
	}
	
}
