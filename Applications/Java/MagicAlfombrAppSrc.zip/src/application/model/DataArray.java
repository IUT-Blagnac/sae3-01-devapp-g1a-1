package application.model;

/**
 * Permet de stocker 10 entier dans l'ordre et supprime le plus vieux quand un nouveau arrive
 */
public class DataArray {
	
	private int[] data;
	private int nbD;
	
	public DataArray() {
		this.data = new int[10];
		this.nbD = 0;
	}
	
	/**
	 * ajoute value aux données
	 * @param value
	 */
	public void add(int value) {
		if (nbD >= 10) {
			for (int i = 0; i < 9; i++) {
				this.data[i] = this.data[i+1];
			}
			nbD = 9;
		}
		this.data[nbD] = value;
		nbD++;
	}
	
	/**
	 * retourne la donnée à l'index index
	 * @param index
	 * @return
	 */
	public int get(int index) {
		return this.data[index];
	}
	
	/**
	 * return le nombre de données dans le tableau
	 * @return
	 */
	public int getLast() {
		return this.nbD;
	}
	
}
