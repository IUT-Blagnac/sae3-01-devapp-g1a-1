package model;

import java.util.List;

public class Config {
	
	public String server;
	public String app;
	public String device;
	public String outFolder;
	
	public List<Boolean> toRead;
	public List<Integer> max;
	public List<Integer> min;
	
	public int timeSleep;
	public int frec;
	
	public Config() {
		this.server = "";
		this.app = "";
		this.device = "";
		this.outFolder = "";
		this.toRead = null;
		this.max = null;
		this.min = null;
		this.timeSleep = 0;
		this.frec = 0;
	}
	
	public Config(String _server, String _app, String _device, String _outFolder, List<Boolean> _toRead, List<Integer> _max, List<Integer> _min, int _timeSleep, int _frec) {
		this.server = _server;
		this.app = _app;
		this.device = _device;
		this.outFolder = _outFolder;
		this.toRead = _toRead;
		this.max = _max;
		this.min = _min;
		this.timeSleep = _timeSleep;
		this.frec = _frec;
	}

	@Override
	public String toString() {
		return "Config [server=" + server + ", app=" + app + ", device=" + device + ", outFolder=" + outFolder
				+ ", toRead=" + toRead + ", max=" + max + ", min=" + min + ", timeSleep=" + timeSleep + ", frec=" + frec
				+ "]";
	}
	
}
