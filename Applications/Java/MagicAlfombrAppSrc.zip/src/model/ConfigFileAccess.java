package model;

import java.io.File;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ConfigFileAccess {
	
	public Config readFile() {
		try {
			File inputFile = new File("config.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	        Document doc = dBuilder.parse(inputFile);
	        doc.getDocumentElement().normalize();
	        
	        Config config = new Config();
	        
	        config.server = doc.getElementsByTagName("server").item(0).getTextContent();
	        config.app = doc.getElementsByTagName("app").item(0).getTextContent();
	        config.device = doc.getElementsByTagName("device").item(0).getTextContent();
	        config.outFolder = doc.getElementsByTagName("outFolder").item(0).getTextContent();
	        
	        config.timeSleep = Integer.parseInt(doc.getElementsByTagName("timeSleep").item(0).getTextContent());
	        config.frec = Integer.parseInt(doc.getElementsByTagName("frec").item(0).getTextContent());
	        
	        ArrayList<String> attributes = new ArrayList<String>();
	        attributes.add("activity");
	        attributes.add("co2");
	        attributes.add("humidity");
	        attributes.add("illumination");
	        attributes.add("infrared");
	        attributes.add("pressure");
	        attributes.add("temperature");
	        attributes.add("tvoc");
	        
	        config.toRead = new ArrayList<Boolean>();
	        NodeList nlist = doc.getElementsByTagName("toDraw");
	        Element toRead = (Element) nlist.item(0);
	        for (String str : attributes) {
	        	config.toRead.add(Boolean.parseBoolean(toRead.getElementsByTagName(str).item(0).getTextContent()));
	        }
	        
	        config.max = new ArrayList<Integer>();
	        nlist = doc.getElementsByTagName("max");
	        Element max = (Element) nlist.item(0);
	        for (String str : attributes) {
	        	config.max.add(Integer.parseInt(max.getElementsByTagName(str).item(0).getTextContent()));
	        }
	        
	        config.min = new ArrayList<Integer>();
	        nlist = doc.getElementsByTagName("min");
	        Element min = (Element) nlist.item(0);
	        for (String str : attributes) {
	        	config.min.add(Integer.parseInt(min.getElementsByTagName(str).item(0).getTextContent()));
	        }
	        
	        return config;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return new Config();
	}
	
	public void writeToFile(Config _config) {
		
		try {
			
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder builder = factory.newDocumentBuilder();
	        Document doc = builder.newDocument();
	        
	        Element root = doc.createElement("config");
	        doc.appendChild(root);
	        
	        root.appendChild(createElement(doc, "server", _config.server));
	        root.appendChild(createElement(doc, "app", _config.app));
	        root.appendChild(createElement(doc, "device", _config.device));
	        root.appendChild(createElement(doc, "outFolder", _config.outFolder));
	        
	        Element toDraw = doc.createElement("toDraw");
	        root.appendChild(toDraw);
	        
	        toDraw.appendChild(createElement(doc, "activity", _config.toRead.get(0).toString().replace('t', 'T').replace('f', 'F')));
	        toDraw.appendChild(createElement(doc, "co2", _config.toRead.get(1).toString().replace('t', 'T').replace('f', 'F')));
	        toDraw.appendChild(createElement(doc, "humidity", _config.toRead.get(2).toString().replace('t', 'T').replace('f', 'F')));
	        toDraw.appendChild(createElement(doc, "illumination", _config.toRead.get(3).toString().replace('t', 'T').replace('f', 'F')));
	        toDraw.appendChild(createElement(doc, "infrared", _config.toRead.get(4).toString().replace('t', 'T').replace('f', 'F')));
	        toDraw.appendChild(createElement(doc, "pressure", _config.toRead.get(5).toString().replace('t', 'T').replace('f', 'F')));
	        toDraw.appendChild(createElement(doc, "temperature", _config.toRead.get(6).toString().replace('t', 'T').replace('f', 'F')));
	        toDraw.appendChild(createElement(doc, "tvoc", _config.toRead.get(7).toString().replace('t', 'T').replace('f', 'F')));
	        
	        Element max = doc.createElement("max");
	        root.appendChild(max);
	        
	        max.appendChild(createElement(doc, "activity", _config.max.get(0).toString()));
	        max.appendChild(createElement(doc, "co2", _config.max.get(1).toString()));
	        max.appendChild(createElement(doc, "humidity", _config.max.get(2).toString()));
	        max.appendChild(createElement(doc, "illumination", _config.max.get(3).toString()));
	        max.appendChild(createElement(doc, "infrared", _config.max.get(4).toString()));
	        max.appendChild(createElement(doc, "pressure", _config.max.get(5).toString()));
	        max.appendChild(createElement(doc, "temperature", _config.max.get(6).toString()));
	        max.appendChild(createElement(doc, "tvoc", _config.max.get(7).toString()));
	        
	        Element min = doc.createElement("min");
	        root.appendChild(min);
	        
	        min.appendChild(createElement(doc, "activity", _config.min.get(0).toString()));
	        min.appendChild(createElement(doc, "co2", _config.min.get(1).toString()));
	        min.appendChild(createElement(doc, "humidity", _config.min.get(2).toString()));
	        min.appendChild(createElement(doc, "illumination", _config.min.get(3).toString()));
	        min.appendChild(createElement(doc, "infrared", _config.min.get(4).toString()));
	        min.appendChild(createElement(doc, "pressure", _config.min.get(5).toString()));
	        min.appendChild(createElement(doc, "temperature", _config.min.get(6).toString()));
	        min.appendChild(createElement(doc, "tvoc", _config.min.get(7).toString()));
	        
	        root.appendChild(createElement(doc, "timeSleep", String.valueOf(_config.timeSleep)));
	        root.appendChild(createElement(doc, "frec", String.valueOf(_config.frec)));
	        
	        TransformerFactory transformerFactory = TransformerFactory.newInstance();
	        Transformer transf = transformerFactory.newTransformer();

	        transf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
	        transf.setOutputProperty(OutputKeys.INDENT, "yes");
	        transf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

	        DOMSource source = new DOMSource(doc);
	        File myFile = new File("config.xml");
	        StreamResult file = new StreamResult(myFile);
	        transf.transform(source, file);
	        
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	private static Node createElement(Document doc, String name, String value) {

        Element node = doc.createElement(name);
        node.appendChild(doc.createTextNode(value));

        return node;
    }
	
}
